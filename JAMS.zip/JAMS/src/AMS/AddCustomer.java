package AMS;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.util.regex.Pattern;

public class AddCustomer extends JFrame implements ActionListener {
    
    JTextField tfname, tfnationality, tfaadhar, tfaddress, tfphone, tfemail;
    JRadioButton rbmale, rbfemale;
    
    public AddCustomer() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel heading = new JLabel("ADD CUSTOMER DETAILS");
        heading.setBounds(220, 20, 500, 35);
        heading.setFont(new Font("Serif", Font.PLAIN, 32));
        heading.setForeground(Color.BLUE);
        add(heading);
        
        JLabel lblname = new JLabel("Name");
        lblname.setBounds(60, 80, 150, 25);
        lblname.setFont(new Font("serif", Font.PLAIN, 16));
        add(lblname);
        
        tfname = new JTextField();
        tfname.setBounds(220, 80, 150, 25);
        add(tfname);
        
        JLabel lblnationality = new JLabel("Nationality");
        lblnationality.setBounds(60, 130, 150, 25);
        lblnationality.setFont(new Font("serif", Font.PLAIN, 16));
        add(lblnationality);
        
        tfnationality = new JTextField();
        tfnationality.setBounds(220, 130, 150, 25);
        add(tfnationality);
        
        JLabel lblaadhar = new JLabel("Aadhar Number");
        lblaadhar.setBounds(60, 180, 150, 25);
        lblaadhar.setFont(new Font("serif", Font.PLAIN, 16));
        add(lblaadhar);
        
        tfaadhar = new JTextField();
        tfaadhar.setBounds(220, 180, 150, 25);
        add(tfaadhar); 
        
        JLabel lbladdress = new JLabel("Address");
        lbladdress.setBounds(60, 230, 150, 25);
        lbladdress.setFont(new Font("serif", Font.PLAIN, 16));
        add(lbladdress);
        
        tfaddress = new JTextField();
        tfaddress.setBounds(220, 230, 150, 25);
        add(tfaddress);
        
        JLabel lblgender = new JLabel("Gender");
        lblgender.setBounds(60, 280, 150, 25);
        lblgender.setFont(new Font("serif", Font.PLAIN, 16));
        add(lblgender);
        
        ButtonGroup gendergroup = new ButtonGroup();
        
        rbmale = new JRadioButton("Male");
        rbmale.setBounds(220, 280, 70, 25);
        rbmale.setBackground(Color.WHITE);
        add(rbmale);
        
        rbfemale = new JRadioButton("Female");
        rbfemale.setBounds(300, 280, 70, 25);
        rbfemale.setBackground(Color.WHITE);
        add(rbfemale);
        
        gendergroup.add(rbmale);
        gendergroup.add(rbfemale);
        
        JLabel lblphone = new JLabel("Phone");
        lblphone.setBounds(60, 330, 150, 25);
        lblphone.setFont(new Font("serif", Font.PLAIN, 16));
        add(lblphone);
        
        tfphone = new JTextField();
        tfphone.setBounds(220, 330, 150, 25);
        add(tfphone);
        
        JLabel lblemail = new JLabel("Email");
        lblemail.setBounds(60, 380, 150, 25);
        lblemail.setFont(new Font("serif", Font.PLAIN, 16));
        add(lblemail);
        
        tfemail = new JTextField();
        tfemail.setBounds(220, 380, 150, 25);
        add(tfemail);
        
        JButton save = new JButton("SAVE");
        save.setBackground(Color.BLACK);
        save.setForeground(Color.WHITE);
        save.setBounds(220, 430, 150, 30);
        save.addActionListener(this);
        add(save);
        
        ImageIcon image = new ImageIcon(ClassLoader.getSystemResource("AMS/icons/emp.png"));
        JLabel lbimage = new JLabel(image);
        lbimage.setBounds(450, 80, 280, 400);
        add(lbimage);
        
        setSize(900, 600);
        setLocation(300, 150);
        setVisible(true);         
    }
    
    public void actionPerformed(ActionEvent ae) {
        String name = tfname.getText().trim();
        String nationality = tfnationality.getText().trim();
        String phone = tfphone.getText().trim();
        String address = tfaddress.getText().trim();
        String aadhar = tfaadhar.getText().trim();
        String email = tfemail.getText().trim();
        String gender = null;

        if (rbmale.isSelected()) {
            gender = "Male";
        } else if (rbfemale.isSelected()) {
            gender = "Female";
        }

        if (name.isEmpty() || nationality.isEmpty() || phone.isEmpty() || address.isEmpty() || aadhar.isEmpty() || email.isEmpty() || gender == null) {
            JOptionPane.showMessageDialog(null, "Please fill in all the details before saving.");
            return;
        } else if ( containsTabOrSpace(nationality) || containsTabOrSpace(phone) ||
                   containsTabOrSpace(address) || containsTabOrSpace(aadhar) || containsTabOrSpace(email)) {
            JOptionPane.showMessageDialog(null, "Tabs or extra spaces are not allowed in any field. Please correct them and try again.");
            return;
        }
        int i=0;
        for(int j=0;j<name.length();j++) {
        	char c=name.charAt(j);
        	if((c>='a'&&c<='z')||(c>='A' && c<='Z')||(c==' ')) {
        		i++;
        	}
        }
        int i1=0;
        for(int j=0;j<nationality.length();j++) {
        	char c=nationality.charAt(j);
        	if((c>='a'&&c<='z')||(c>='A' && c<='Z')||(c==' ')) {
        		i1++;
        	}
        }
         if(i!=name.length()) {
        	 JOptionPane.showMessageDialog(null, "Please enter valid name.");
        	 return;
         }
         if(i1!=nationality.length()) {
        	 JOptionPane.showMessageDialog(null, "Please enter valid Nationality.");
        	 return;
         }
        if (!aadhar.matches("\\d{12}")) {
            JOptionPane.showMessageDialog(null, "Aadhar number should be exactly 12 digits and Characters are not allowed.");
            return;
        }

        if (!phone.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(null, "Phone number should be exactly 10 digits.");
            return;
        }

        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
            return;
        }

        try {
            Conn conn = new Conn();
            String query = "INSERT INTO passenger (name, nationality, phone, address, aadhar, email, gender) VALUES ('" + name + "','" + nationality + "','" + phone + "', '" + address + "', '" + aadhar + "', '" + email + "', '" + gender + "')";
            conn.s.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Customer Details Added Successfully");
            setVisible(false);  

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean containsTabOrSpace(String input) {
        return input.contains("\t") || input.contains(" ");
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return Pattern.matches(emailRegex, email);
    }
    
    public static void main(String[] args) {
        new AddCustomer();
    }
}


