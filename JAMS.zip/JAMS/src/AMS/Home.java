package AMS;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.sql.*;


public class Home extends JFrame implements ActionListener{
	 
	public Home() {
		 setLayout(null);
		 
		 ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("AMS/icons/front.jpg"));
		 
		Image image1 = i1.getImage();
		Image modifiedDabImage = image1.getScaledInstance(1600,800,java.awt.Image.SCALE_SMOOTH);
		i1=new ImageIcon(modifiedDabImage);
		 
		 JLabel image = new JLabel(i1);
		 image.setBounds(0,0,1600,800);
		 add(image);
		 
		 JLabel heading = new JLabel("AIR INDIA WELCOMES YOU");
		 heading.setBounds(500,20,1000,40);
		 heading.setForeground(Color.BLACK);
		 heading.setFont(new Font("Serif", Font.BOLD,36));
		 image.add(heading);
		 
		 JMenuBar menubar = new JMenuBar();
		 setJMenuBar(menubar);
		 
		 JMenu details = new JMenu("Details");
		 menubar.add(details);
		 

		 JMenuItem flightDetails = new JMenuItem("Flight Details");
		 flightDetails.addActionListener(this);
		 details.add(flightDetails);
		 
		 JMenuItem customerDetails = new JMenuItem("Add Customer Details");
		 customerDetails.addActionListener(this);
		 details.add(customerDetails);
		 
		 JMenuItem bookFlight = new JMenuItem ("Book Flight");
		 bookFlight.addActionListener(this);
		 details.add(bookFlight);
		 
		 JMenuItem journeyDetails = new JMenuItem("Journey Details");
		 journeyDetails.addActionListener(this);
		 details.add(journeyDetails);
		 
		 JMenuItem ticketCancellation = new JMenuItem("Cancel Ticket");
		 ticketCancellation.addActionListener(this);
		 details.add(ticketCancellation );
		 
		 JMenu ticket = new JMenu("Ticket");
		 menubar.add(ticket);
		 

		 JMenuItem boardingPass = new JMenuItem("Boarding Pass");
		 boardingPass.addActionListener(this);
		 ticket.add(boardingPass);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setLocation(600, 250);
		setVisible(true);
	}
	
    public void actionPerformed(ActionEvent ae) {
    	String text = ae.getActionCommand();
    	if(text.equals("Add Customer Details")) {
    		new AddCustomer();
    	}else if(text.equals("Flight Details")){
    		new FlightInfo();
    	}else if(text.equals("Book Flight")){
    		new BookFlight();
    	}else if(text.equals("Journey Details")){
    		new JourneyDetails();
    	}else if(text.equals("Cancel Ticket")){
    		new Cancel();
    	}
    	 else if(text.equals("Boarding Pass")){
    		new BoardingPass();
    	
    	}
    }
    
	public static void main(String[] args) {
		new Home();
	}
}
