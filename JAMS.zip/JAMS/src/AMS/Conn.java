package AMS;
import java.sql.*;


public class Conn {
	Connection c;
	Statement s;
	public Conn() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");//Registering the driver
			c = DriverManager.getConnection("jdbc:mysql:///airlinemanagementsystem","root","@Sindhu098"); //Create the connection string
			s = c.createStatement(); 
		
			} catch (Exception e) {
			e.printStackTrace();
	      }
      }
	
	}



